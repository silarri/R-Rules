// Postion & Weather context
import React from 'react';
import Expo, {
    Constants, Location, Calendar,
    Permissions, Pedometer
} from 'expo';
import {
    AppRegistry, Image, Platform,
    StyleSheet, View, Alert,
    AsyncStorage, ActivityIndicator
} from 'react-native';
import oauth from "../oauth";   // root/oauth.js
import * as LocationDB from "../sqlite/location";

/**
 * Retrieves current location
 */
export async function _getLocationAsync() {
    try {
        // Ask for location permission
        let { status } = await Permissions.askAsync(Permissions.LOCATION);
        if (status !== 'granted') {
            throw 'Permission to access location was denied';
        }

        let location = await Location.getCurrentPositionAsync({});
        // this.setState({ location: location }); <-
        // Save location to db & SQLite db 
        await AsyncStorage.setItem('location', JSON.stringify(location));
        // LocationDB.saveLocation(location);
        // Call _getCurrentWeather
        await _getCurrentWeather(location);
    } catch (error) {
        // Error saving location 
        console.log(error);
    }
};

/**
 * Retrieves current weather for the location
 */
export async function _getCurrentWeather(location) {
    let lat = location.coords.latitude;
    let lon = location.coords.longitude;

    // Retrieve conditions using current coordinates
    // Temperature -> Kelvins
    // Kelvin2Celsiuis(k) return c => k = c - 273,15
    try {
        let response = await fetch(
            'http://api.openweathermap.org/data/2.5/weather' +
            '?lat=' + lat + '&lon=' + lon +
            '&appid=' + oauth.openweathermap
        );
        let resJson = await response.json();
        // Set data & AsyncStorage
        //AsyncStorage.setItem('weather', JSON.stringify(resJson));
        AsyncStorage.setItem('weather', resJson);
    } catch (error) {
        // Error routine
        console.log(error);
    }

};

/**
 * Retrieves coordinates from FB user
 */
export async function _getFacebookCoordinates() {
    try {
        let user = await AsyncStorage.getItem('user');
        let addres = user.location.name;
        let response = await fetch(
            'https://maps.googleapis.com/maps/api/geocode/json' +
            '?address=' + addres +
            '&key=' + oauth.androidGoogle
        );
        let resJson = await response.json();
        // AsyncStorage
        AsyncStorage.setItem('FBPosition', resJson);
    } catch (error) {
        // Error routine
        console.log(error);
    }

};