// Calendar context
import React from 'react';
import Expo, {
    Constants, Location, Calendar,
    Permissions, Pedometer
} from 'expo';
import {
    AppRegistry, Image, Platform,
    StyleSheet, View, Alert,
    AsyncStorage, ActivityIndicator
} from 'react-native';
import oauth from "../oauth";   // root/oauth.js

/**
 * Retrieves calendar events for this week
 */
export async function _getCalendarAsync() {
    try {
        let {  status } = await Permissions.askAsync('calendar');  // Permissions.CALENDAR -> 'calendar'
        if (status !== 'granted') {
            throw 'Permission to access calendar was denied';
        }
        // Gets an array of Calendars
        let calendars = await Calendar.getCalendarsAsync();
        AsyncStorage.setItem('calendars', JSON.stringify(calendars));
        // Calendar events
        let calendarIds = [];
        const end = new Date();
        const start = new Date();
        end.setDate(start.getDate() + 7);   // Ends in 7 days
        for (let index = 0; index < calendars.length; index++) {
            calendarIds.push(calendars[index].id + ''); // Add (string) Calendar Id
        }
        // console.log(calendarIds);
        let events = await Calendar.getEventsAsync(calendarIds, start, end);
        AsyncStorage.setItem('events', JSON.stringify(events));

    } catch (error) {
        console.log(error);
    }
}