// Calendar context
import React from 'react';
import Expo, {
    Constants, Location, Calendar,
    Permissions, Pedometer, Notifications
} from 'expo';
import {
    AppRegistry, Image, Platform,
    StyleSheet, View, Alert,
    AsyncStorage, ActivityIndicator
} from 'react-native';

export async function _registerForPushNotificationsAsync() {

    try {
        // Only IOs
        if (Platform.OS == "ios") {
            const { status: existingStatus } = await Permissions.getAsync(
                Permissions.NOTIFICATIONS
            );
            let finalStatus = existingStatus;
    
            // only ask if permissions have not already been determined, because
            // iOS won't necessarily prompt the user a second time.
            if (existingStatus !== 'granted') {
                // Android remote notification permissions are granted during the app
                // install, so this will only ask on iOS
                const { status } = await Permissions.askAsync(Permissions.NOTIFICATIONS);
                finalStatus = status;
            }
    
            // Stop here if the user did not grant permissions
            if (finalStatus !== 'granted') {
                return;
            } 
        }
        // End of only IOs

        // Get the token that uniquely identifies this device
        let token = await Notifications.getExpoPushTokenAsync();
        console.log(token);

    } catch (error) {
        console.log(error);
    }

}