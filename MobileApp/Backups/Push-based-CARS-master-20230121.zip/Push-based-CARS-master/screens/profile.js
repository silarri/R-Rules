import React from 'react';
import * as Expo from 'expo';
import {
    StyleSheet, View, ToolbarAndroid,
    Alert, AsyncStorage
} from 'react-native';
import {
    Container, Button, Icon,
    Text, Footer, FooterTab, 
} from 'native-base';
import { Provider } from "react-redux";
import { StackNavigator, NavigationAction } from "react-navigation";
// UI
import NavFooter from "./components/navFooter";
import TopSpace from "./components/topSpace";
export default class ProfileScreen extends React.Component {

    // Constructor
    constructor(props) {
        super(props);
    }

    // Click on Footer
    onPressFooter(data) {
        this.props.navigation.navigate(data);
    }

    async logOut() {
        try {
            // Remove user & token from db
            this.setState({ token: null, user: null });
            await AsyncStorage.removeItem('user');
            await AsyncStorage.removeItem('token');
            // Clean stack & navigate to login
            this.props.navigation.popToTop();
        } catch (error) {
            
        }
    }

    render() {
        return (
            <Container>
                <TopSpace/>
                <ToolbarAndroid
                    title="Profile"
                    actions={[]}
                    onActionSelected={this.onActionSelected}
                    style={styles.toolbar}
                    titleColor='white'
                />
                <View style={styles.logout}>
                    <Button danger
                        onPress={this.logOut.bind(this)}>
                        <Text>Log out</Text>
                    </Button>
                </View>
                <NavFooter navigation={this.props.navigation} tab={"Profile"}/>
            </Container>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#fff',
    },
    toolbar: {
        height: '8%',
        backgroundColor: '#3F51B5', // Primary color
    },
    logout: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: '30%',
        marginBottom: '40%',
    }
});