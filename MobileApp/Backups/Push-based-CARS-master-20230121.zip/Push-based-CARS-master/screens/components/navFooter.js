import React from 'react';
import Expo, {
    Constants, Location, Calendar,
    Permissions, Pedometer
} from 'expo';
import {
    AppRegistry, Image, Platform,
    StyleSheet, View, Alert,
    AsyncStorage, ActivityIndicator
} from 'react-native';
import {
    Button, Icon,
    Footer, FooterTab
} from 'native-base';
import { Provider } from "react-redux";


class NavFooter extends React.Component {
    // Constructor
    constructor(props) {
        super(props);
        // console.log(props); debug
        this.state = {
            tab: null,
        }
    }

    // Set active tab
    componentWillMount() {
        this.setState({
            tab: this.props.tab
        });
    }

    // Click on Footer
    onPressFooter(data) {
        this.props.navigation.navigate(data);
    }

    render() {
        return (
            <Footer>
                <FooterTab>
                    <Button active={(this.state.tab == "Home")} onPress={() => this.onPressFooter('Home')}>
                        <Icon name="home" />
                    </Button>
                    <Button active={(this.state.tab == "Settings")} onPress={() => this.onPressFooter('Settings')}>
                        <Icon name="settings" />
                    </Button>
                    <Button active={(this.state.tab == "Profile")} onPress={() => this.onPressFooter('Profile')}>
                        <Icon name="person" />
                    </Button>
                    <Button active={(this.state.tab == "Context")} onPress={() => this.onPressFooter('Context')}>
                        <Icon name="cloud" />
                    </Button>
                </FooterTab>
            </Footer>
        );
    }
}

export default NavFooter