import React from 'react';
import Expo, {
    Constants, Location, Calendar,
    Permissions, Pedometer
} from 'expo';
import {
    AppRegistry, Image, Platform,
    StyleSheet, View, Alert,
    AsyncStorage, ActivityIndicator
} from 'react-native';
import {
    Container, Button, Text,
    Icon
} from 'native-base';
import { Provider } from "react-redux";
import { StackNavigator } from "react-navigation";
import oauth from "../oauth";   // root/oauth.js
// Database
const db = Expo.SQLite.openDatabase('cars.db');
import * as LocationDB from "../sqlite/location";
// Events
import * as myCalendar from "../event/calendar";
import * as myPosition from "../event/position";
import * as myNotification from "../event/notification";
// Icon
import icon from "../icon.png";

export default class LoginScreen extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            location: null,
            weather: null,
            errorMessage: null,
        }
    }

    async componentWillMount() {
        try {
            // Allow notifications
            myNotification._registerForPushNotificationsAsync();
            // Calendar
            myCalendar._getCalendarAsync();
            // Get location & current weather
            this._getConditionsAsync();
            user = await AsyncStorage.getItem('user');
            token = await AsyncStorage.getItem('token');
            if (user !== null && token !== null) {
                // Update State
                this.setState({
                    user: user,
                    token: token,
                });
                // Set Facebook location
                this._getFacebookCoordinates();
                // Navigate to home
                this.props.navigation.navigate('Home');
            } else {
                // No user available
                this.props.navigation.navigate('Login');
            }
        } catch (error) {
            // Error - repeat login
            console.log(error);   // debug
            this.props.navigation.navigate('Login');
        }
    }

    _getFacebookCoordinates = async () => {
        try {
            let user = await AsyncStorage.getItem('user');
            user = JSON.parse(user);
            let address = user.location.name;
            let response = await fetch(
                'https://maps.googleapis.com/maps/api/geocode/json' +
                '?address=' + address +
                '&key=' + oauth.androidGoogle
            );
            let resJson = await response.json();
            let position = JSON.parse('{' +
                '"formatted_address": "' + resJson.results[0].formatted_address + '", ' +
                '"location": ' + JSON.stringify(resJson.results[0].geometry.location) +
                '}'
            );
            // AsyncStorage
            AsyncStorage.setItem('FBPosition', JSON.stringify(position));
        } catch (error) {
            // Error routine
            console.log(error);
            console.log(error);
        }

    };

    _getCalendarAsync = async () => {
        try {
            let { status } = await Permissions.askAsync('calendar');  // Permissions.CALENDAR -> 'calendar'
            if (status !== 'granted') {
                throw 'Permission to access calendar was denied';
            }
            // Gets an array of Calendars
            let calendars = await Calendar.getCalendarsAsync();
            AsyncStorage.setItem('calendars', JSON.stringify(calendars));
        } catch (error) {
            // console.log(error);
        }
    }

    _getConditionsAsync = async () => {
        try {
            await myPosition._getLocationAsync();
            await myPosition._getCurrentWeather();
        } catch (error) {
            // Error
            console.log(error);
        }
    }

    render() {
        return (
            <View style={styles.view}>
                {/*<Text style={styles.title}> CARS </Text>*/}
                <Image style={styles.icon} source={icon} />
                {
                    /*<View style={styles.load}>
                        <Text> Loading </Text>
                        <ActivityIndicator size="small" color="black" />
                    </View>*/
                }
            </View>
        );
    }
}


const styles = StyleSheet.create({
    view: {
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100%',
    },
    title: {
        marginBottom: 10,
        fontSize: 25,
    },
    icon: {
        height: 120,
        width: 120,
    },
    load: {
        marginTop: 10,
        flexDirection: 'row',
    }
});