import React from 'react';
import * as Expo from 'expo';
import {
    StyleSheet, View, ToolbarAndroid,
    TextInput,
} from 'react-native';
import {
    Header, Body, Container,
    Button, Icon, List, ListItem,
    Left, Right, Title, Content,
    Footer, FooterTab, Form, Picker,
    Text, CheckBox
} from 'native-base';
import { Provider } from "react-redux";
import { StackNavigator } from "react-navigation";
// UI
import NavFooter from "./components/navFooter";
import TopSpace from "./components/topSpace";
export default class SettingsScreen extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            selected: "1",
            checkAll: false,
            checkSport: false,
            checkShow: false,
            checkEdu: false,
        };
    }

    // Click on save button
    onSaveSettings() {
        // do something
    }

    // Select all
    onPressAllCb() {
        // swap checkboxes value
        swap = !this.state.checkAll;
        this.setState({
            checkSport: swap,
            checkShow: swap,
            checkEdu: swap,
            checkAll: swap,
        });
    }

    // Select one
    onPressCb(activity) {
        // do something
        if (activity == 'checkSport')
            this.setState({ checkSport: !this.state.checkSport });
        else if (activity == 'checkShow')
            this.setState({ checkShow: !this.state.checkShow });
        else if (activity == 'checkEdu')
            this.setState({ checkEdu: !this.state.checkEdu });
    }

    // Click on Footer
    onPressFooter(data) {
        this.props.navigation.navigate(data);
    }

    render() {
        return (
            <Container>
                <TopSpace/>
                <ToolbarAndroid
                    title="Settings"
                    actions={[]}
                    onActionSelected={this.onActionSelected}
                    style={styles.toolbar}
                    titleColor='white'
                />
                <Content>
                    <List style={styles.section}>
                        <Title style={styles.sectionTitle}> Activities to display </Title>
                        <ListItem onPress={this.onPressAllCb.bind(this)}>
                            <CheckBox checked={this.state.checkAll} />
                            <Body>
                                <Text>Select all</Text>
                            </Body>
                        </ListItem>
                        <ListItem onPress={() => this.onPressCb('checkSport')}>
                            <CheckBox checked={this.state.checkSport} />
                            <Body>
                                <Text>Sports</Text>
                            </Body>
                        </ListItem>
                        <ListItem onPress={() => this.onPressCb('checkShow')}>
                            <CheckBox checked={this.state.checkShow} />
                            <Body>
                                <Text>Shows</Text>
                            </Body>
                        </ListItem>
                        <ListItem onPress={() => this.onPressCb('checkEdu')}>
                            <CheckBox checked={this.state.checkEdu} />
                            <Body>
                                <Text>Education</Text>
                            </Body>
                        </ListItem>
                    </List>
                    <View style={styles.saveButton}>
                        <Button primary
                            onPress={this.onSaveSettings.bind(this)}>
                            <Text>Save Settings</Text>
                        </Button>
                    </View>
                </Content>
                <NavFooter navigation={this.props.navigation} tab={"Settings"}/>
            </Container>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#fff',
    },
    toolbar: {
        height: '8%',
        backgroundColor: '#3F51B5', // Primary color
    },
    section: {
        flex: 1,
        marginTop: '5%',
    },
    sectionTitle: {
        marginBottom: '3%',
        marginHorizontal: '3%',
        color: 'black',
        justifyContent: 'flex-start',
    },
    saveButton: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: '20%',
        marginBottom: '20%',
    }
});