import React from 'react';
import Expo from 'expo';
import {
    ToolbarAndroid, AppRegistry,
    StyleSheet, View, Alert,
    AsyncStorage
} from 'react-native';
import {
    Container, Button, Text,
    Icon
} from 'native-base';
import { Provider } from "react-redux";
import { StackNavigator } from "react-navigation";
import oauth from "../oauth";   // root/oauth.js
// Database
const db = Expo.SQLite.openDatabase('cars.db');
import * as User from "../sqlite/user";
// UI
import TopSpace from "./components/topSpace";
export default class LoginScreen extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            user: null,
            token: null,
        };
    }

    async componentDidMount() {
        try {
            user = await AsyncStorage.getItem('user');
            token = await AsyncStorage.getItem('token');
            if (user !== null && token !== null) {
                // Update State
                this.setState({
                    user: user,
                    token: token,
                });
                // Navigate to home
                this.props.navigation.navigate('Home');
            }
        } catch (error) {

        }
    }

    async logInFacebook() {
        try {

            const { type, token } = await Expo.Facebook.logInWithReadPermissionsAsync(oauth.facebookAppID, {
                permissions: ['public_profile'],
            });
            if (type === 'success') {
                // Get the user's name using Facebook's Graph API
                const response = await fetch(
                    'https://graph.facebook.com/me?' +
                    'fields=id,name,birthday,location' +
                    '&access_token=' + token);
                // Insert user info to db
                userFB = await response.json();
                // Store data: user & token
                await AsyncStorage.setItem('user', JSON.stringify(userFB));
                await AsyncStorage.setItem('token', token);
                // Update state
                this.setState({ token: token, user: user });
                // Navigate to home
                this.props.navigation.navigate('Home');
            }
        } catch (e) {
            // Error; Update state & db
            this.setState({ token: null, user: null });
            await AsyncStorage.removeItem('user');
            await AsyncStorage.removeItem('token');
            return { error: true };
        }
    }

    render() {
        return (
            <Container>
                <TopSpace />
                <ToolbarAndroid
                    title="AwesomeApp"
                    actions={[]}
                    onActionSelected={this.onActionSelected}
                    style={styles.toolbar}
                    titleColor='white'
                />
                <View style={styles.facebook}>
                    <Button primary
                        onPress={this.logInFacebook.bind(this)}>
                        <Icon name='logo-facebook' />
                        <Text>Sign in with Facebook</Text>
                    </Button>
                </View>

            </Container>
        );
    }
}


const styles = StyleSheet.create({
    container: {
        backgroundColor: '#fff',
    },
    toolbar: {
        height: '8%',
        backgroundColor: '#3F51B5', // Primary color
    },
    facebook: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: '30%',
        marginBottom: '40%',
    }
});