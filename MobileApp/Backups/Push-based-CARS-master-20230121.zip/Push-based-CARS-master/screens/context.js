import React from 'react';
import * as Expo from 'expo';
import {
    StyleSheet, View, ToolbarAndroid,
    Alert, AsyncStorage
} from 'react-native';
import {
    Container, Button, Icon,
    Text, Footer, FooterTab, 
} from 'native-base';
import { Provider } from "react-redux";
import { StackNavigator, NavigationAction } from "react-navigation";
// UI
import NavFooter from "./components/navFooter";
import TopSpace from "./components/topSpace";
export default class ContextScreen extends React.Component {

    // Constructor
    constructor(props) {
        super(props);
    }

    // Click on Footer
    onPressFooter(data) {
        this.props.navigation.navigate(data);
    }

    // Click on InfoBtn
    async onInfobtn(item){
        try {
            info = await AsyncStorage.getItem(item);
            alert(info);
            console.log(info);
        } catch (error) {
            
        }
    }

    render() {
        return (
            <Container>
                <TopSpace/>
                <ToolbarAndroid
                    title="Profile"
                    actions={[]}
                    onActionSelected={this.onActionSelected}
                    style={styles.toolbar}
                    titleColor='white'
                />
                <View style={styles.context}>
                    <Button
                        style={styles.btn}
                        onPress={() => this.onInfobtn('user')}>
                        <Text>Facebook User</Text>
                    </Button>

                    <Button
                        style={styles.btn}
                        onPress={() => this.onInfobtn('location')}>
                        <Text>Location</Text>
                    </Button>

                    <Button
                        style={styles.btn}
                        onPress={() => this.onInfobtn('FBPosition')}>
                        <Text>Facebook Location</Text>
                    </Button>

                    <Button
                        style={styles.btn} 
                        onPress={() => this.onInfobtn('weather')}>
                        <Text>Weather</Text>
                    </Button>

                    <Button
                        style={styles.btn} 
                        onPress={() => this.onInfobtn('calendars')}>
                        <Text>Calendars</Text>
                    </Button>

                    <Button
                        style={styles.btn} 
                        onPress={() => this.onInfobtn('events')}>
                        <Text>Events</Text>
                    </Button>

                </View>
                <NavFooter navigation={this.props.navigation} tab={"Context"}/>
            </Container>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#fff',
    },
    toolbar: {
        height: '8%',
        backgroundColor: '#3F51B5', // Primary color
    },
    context: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: '30%',
        marginBottom: '40%',
    },
    btn: {
        
    }
});