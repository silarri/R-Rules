import React from 'react';
import * as Expo from 'expo';
import {
    StyleSheet, Text, View, ToolbarAndroid,
    DrawerLayoutAndroid, Slider, ListView,
    TouchableOpacity, Alert, RefreshControl
} from 'react-native';
import {
    Header, Body, Container,
    Button, Icon, List, ListItem,
    Left, Right, Title, Content,
    Footer, FooterTab, FlatList
} from 'native-base';
import { Provider } from "react-redux";
// EMs
import * as EMfetch from "../em/fetch";
// Events
import * as myCalendar from "../event/calendar";
import * as myPosition from "../event/position";
import * as myNotification from "../event/notification";
// UI
import NavFooter from "./components/navFooter";
import TopSpace from "./components/topSpace";

// Data
const activities = [
    'Simon Mignolet',
    'Nathaniel Clyne',
    'Dejan Lovren',
    'Mama Sakho',
    'Alberto Moreno',
    'Emre Can',
    'Joe Allen',
    'Phil Coutinho',
];

export default class HomeScreen extends React.Component {
    // Constructor
    constructor(props) {
        super(props);
        this.ds = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });
        this.state = {
            basic: true,
            listViewData: activities,
            isLoading: true,
            refreshing: false,
            notification: {},
        };
    }
    // Delete row selected
    deleteRow(secId, rowId, rowMap) {
        alert('secId: ' + secId + ' rowId: ' + rowId + ' rowMap: ' + rowMap);
        rowMap[`${secId}${rowId}`].props.closeRow();
        const newData = [...this.state.listViewData];
        newData.splice(rowId, 1);
        //this.setState({ listViewData: newData });
        this.state.listViewData = newData;
    }

    // Loads fonts
    async componentWillMount() {
        try {
            this.loadFonts();
        } catch (error) {
            console.log(error);
        }
    }

    async componentDidMount() {
        try {
            // Send message to EMs
            // I'm here!
            //EMfetch.notifyUser();
            // Allow notifications
            myNotification._registerForPushNotificationsAsync();
            // Handle notifications that are received or selected while the app
            // is open. If the app was closed and then opened by tapping the
            // notification (rather than just tapping the app icon to open it),
            // this function will fire on the next tick after the app starts
            // with the notification data.
            this._notificationSubscription = Expo.Notifications.addListener(this._handleNotification);
        } catch (error) {
            console.log(error);
        }
    }

    _handleNotification = (notification) => {
        this.setState({ notification: notification });
        console.log(notification);
        // Go to Home screen
        this.props.navigation.navigate('Home');
    };

    // Click on ListItem
    onPressButton(data) {
        this.props.navigation.navigate('Activity');
    }

    // Click on Footer
    onPressFooter(data) {
        this.props.navigation.navigate(data);
    }

    async loadFonts() {
        try {
            await Expo.Font.loadAsync({
                Roboto: require("native-base/Fonts/Roboto.ttf"),
                Roboto_medium: require("native-base/Fonts/Roboto_medium.ttf")
            });
            this.setState({ isLoading: false });
        } catch (error) {

        }
    }

    // Refresh list - bind new data
    onRefresh() {
        this.state.refreshing = true;
        this.state.listViewData = activities;
        this.state.refreshing = false;
    }

    render() {
        return (
            <Container style={styles.container}>
                <TopSpace />
                <ToolbarAndroid
                    title="AwesomeApp"
                    actions={[]}
                    onActionSelected={this.onActionSelected}
                    style={styles.toolbar}
                    titleColor='white'
                />
                <Text>{"\n"}</Text>
                <List
                    refreshControl={
                        <RefreshControl
                            refreshing={this.state.refreshing}
                            onRefresh={this.onRefresh()}
                        />
                    }
                    dataSource={this.ds.cloneWithRows(this.state.listViewData)}
                    renderRow={data =>
                        <ListItem>
                            <TouchableOpacity onPress={() => this.onPressButton(data)}>
                                <Text> {data} </Text>
                            </TouchableOpacity>
                        </ListItem>
                    }
                    renderLeftHiddenRow={data =>
                        <Button full onPress={() => alert(data)}>
                            <Icon active name="information-circle" />
                        </Button>}
                    renderRightHiddenRow={(data, secId, rowId, rowMap) =>
                        <Button full danger onPress={_ => this.deleteRow(secId, rowId, rowMap)}>
                            <Icon active name="trash" />
                        </Button>}
                    leftOpenValue={75}
                    rightOpenValue={-75}
                />
                <NavFooter navigation={this.props.navigation} tab={"Home"} />
            </Container>

        );
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#fff',
    },
    toolbar: {
        height: '8%',
        backgroundColor: '#3F51B5', // Primary color
    },
});
