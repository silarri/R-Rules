import React from 'react';
import * as Expo from 'expo';
import {
    StyleSheet, Text, View, ToolbarAndroid,
    DrawerLayoutAndroid, Slider, ListView,
    TouchableOpacity, Alert, Image
} from 'react-native';
import {
    Header, Body, Container,
    Button, Icon, List, ListItem,
    Left, Right, Title, Content,
    Footer, FooterTab
} from 'native-base';
import { Provider } from "react-redux";
import { StackNavigator } from "react-navigation";
import StarRating from 'react-native-star-rating';
// UI
import NavFooter from "./components/navFooter";
import TopSpace from "./components/topSpace";

export default class ActivityScreen extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            starCount: 3.5
        };
    }

    onStarRatingPress(rating) {
        this.setState({
            starCount: rating
        });
    }

    render() {
        return (
            <Container>
                <TopSpace/>
                <ToolbarAndroid
                    title="Título de la Actividad"
                    actions={[]}
                    onActionSelected={this.onActionSelected}
                    style={styles.toolbar}
                    titleColor='white'
                />
                <Content>
                    <Image
                        style={styles.img}
                        source={{ uri: 'https://images5.alphacoders.com/349/thumb-1920-349660.jpg' }}
                    />
                    <View style={{ flex: 1, flexDirection: 'row' }}>
                        <View style={styles.type}>
                            <Text> #Categoría </Text>
                        </View>
                        <View style={styles.rating}>
                            <StarRating
                                disabled={false}
                                emptyStar={'ios-star-outline'}
                                fullStar={'ios-star'}
                                halfStar={'ios-star-half'}
                                iconSet={'Ionicons'}
                                maxStars={5}
                                rating={this.state.starCount}
                                selectedStar={(rating) => this.onStarRatingPress(rating)}
                                fullStarColor={'red'}
                                emptyStarColor={'red'}
                                starSize={20}
                            />
                        </View>
                    </View>
                    <Text style={styles.description}>Descripción de la actividad.</Text>
                    <Text style={styles.description}>
                        But why smiling man her imagine married. Chiefly can man her out believe manners cottage colonel unknown. Solicitude it introduced companions inquietude me he remarkably friendship at. My almost or horses period. Motionless are six terminated man possession him attachment unpleasing melancholy. Sir smile arose one share. No abroad in easily relied an whence lovers temper by. Looked wisdom common he an be giving length mr.
                    </Text>
                </Content>
                <NavFooter navigation={this.props.navigation} tab={"Activity"}/>
            </Container>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#fff',
    },
    toolbar: {
        height: '8%',
        backgroundColor: '#3F51B5', // Primary color
    },
    img: {
        width: '100%',
        height: 150,
        borderWidth: 2,
    },
    description: {
        marginTop: 5,
        marginLeft: 5,
        marginRight: 5,
    },
    type: {
        width: '50%',
        height: 50,
    },
    rating: {
        width: '50%',
        height: 50,
    }
});