import React from 'react';
import Expo from 'expo';
import {
    AsyncStorage
} from 'react-native';
import * as EM from "./ems";

export async function notifyUser() {
    try {
        // get current user
        currentUser = await AsyncStorage.getItem('user');
        // Parse object to JSON
        user = JSON.parse(currentUser);
        const managers = EM.list;
        for (let index = 0; index < managers.length; index++) {
            const em = managers[index];
            // Check if location is adecuated
            // Send request
            let response = await fetch(em.address + '/add/user/' + user.id + '/');
        }
    } catch (error) {
        // handle error here!
        console.log(error);
    }
}

