import React from 'react';
import Expo, { SQLite } from 'expo';
import {
  StyleSheet, Text, View
} from 'react-native';
import {
  Header, Body, Container
} from 'native-base';
import { Provider } from "react-redux";
import { StackNavigator } from "react-navigation";

// Screens
import HomeScreen from "./screens/home";
import ActivityScreen from "./screens/activity";
import ProfileScreen from "./screens/profile";
import SettingsScreen from "./screens/settings";
import LoginScreen from "./screens/login";
import LoadingScreen from "./screens/loading";
import ContextScreen from "./screens/context";
import NavFooter from "./screens/components/navFooter";

// Database
const db = SQLite.openDatabase('cars.db');
import * as User from "./sqlite/user";

const AppNavigator = StackNavigator(
  {
    Home: { screen: HomeScreen },
    Activity: { screen: ActivityScreen },
    Profile: { screen: ProfileScreen },
    Settings: { screen: SettingsScreen },
    Login: { screen: LoginScreen },
    Loading: { screen: LoadingScreen },
    Context: { screen: ContextScreen },
  },
  {
    initialRouteName: "Loading",
    headerMode: "none"
  }
);

export default class App extends React.Component {
  // Constructor
  constructor(props) {
    super(props);
    this.state = {
      basic: true,
      isLoading: true,
      user: null,
    };
  }

  // Loads fonts
  componentWillMount() {
    this.loadFonts();
    this.prepareDatabase();
  }

  async loadFonts() {
    await Expo.Font.loadAsync({
      Roboto: require("native-base/Fonts/Roboto.ttf"),
      Roboto_medium: require("native-base/Fonts/Roboto_medium.ttf")
    });
    this.setState({ isLoading: false });
  }

  // Create table if not exits
  prepareDatabase() {
    db.transaction(tx => {
      tx.executeSql(
        'create table if not exists user (' +
        'userID text primary key not null, ' +
        'logger integer not null, ' + // 0 -> false; 1 -> true
        'birthday text, ' +
        'sex text, ' +
        'picture text ' +
        ');', [],
        //(_, ok) => alert(JSON.stringify(ok)),
        //(_, error) => alert('Error: ' + JSON.stringify(error))
      );
    })    
  }

  render() {
    if (this.state.isLoading) {
      return <Expo.AppLoading />;
    } else {
      return (
        <Container>
          <AppNavigator />
        </Container>

      );
    }
  }
}

const styles = StyleSheet.create({});
