import React from 'react';
import Expo, {
    SQLite
} from 'expo';
import {
    Provider
} from "react-redux";

export function selectUser(db, callback = () => {}) {
    ok = null;  // ResultSet
    rs = null;
    db.transaction(tx => {
        tx.executeSql(
            'select * from user where logger = 1', 
            [], (_, ok) => callback(ok),
            (_, error) => alert('Select error: ' + JSON.stringify(error)),
        );
    });
}

export async function selectUserReturn(db) {
    try {
        await db.transaction(tx => {
            tx.executeSql(
                'select * from user where logger = 1', 
                [], (_, ok) => { return ok; },
                (_, error) => { return error; },
            );
        });
    } catch (error) {
        return {error: true};
    }
    
}

export function modifyUser(db, user) {
    if (this.selectUser(user.userID) == false) {
        // Insert user
        db.transaction(tx => {
            tx.executeSql(
                'insert into user (userID, logger, birthday, sex, picture) values (' + 
                    user.active + ', ' + user.birthday + ', ' + 
                    user.sex + ', ' + user.picture + ');'
            );
        });
    } else {
        // Update user
        db.transaction(tx => {
            tx.executeSql(
                'update user set logger = ? where userID = ?;', [user.active], [user.userID]
            );
        });
    }
}