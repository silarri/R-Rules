import React from 'react';
import Expo, { SQLite } from 'expo';
// Database
const db = SQLite.openDatabase('cars.db');

export async function saveLocation(location) {
    try { 
        await createTable();
        // Insert
        db.transaction(tx => {
            tx.executeSql(
                'insert into location (timestamp, longitude, latitude, speed) values (?,?,?);',
                [location.timestamp, location.coords.longitude, 
                    location.coords.latitude, location.coords.speed],
                //(_, ok) => alert('location inserted!'),
                //(_, error) => alert(JSON.stringify(error))
            );
        });
    } catch (error) {
        // Error
    }
}

async function createTable() {
    try {
        await db.transaction(tx => {
            tx.executeSql(
                'create table if not exists location (' +
                'timestamp integer primary key not null, ' +
                'longitude real not null, ' + 
                'latitude real not null, ' +
                'speed real);', [],
                //(_, ok) => ,
                //(_, error) => alert(JSON.stringify(error))
            );
        });
    } catch (error) {
        return { error: true };
    }

}